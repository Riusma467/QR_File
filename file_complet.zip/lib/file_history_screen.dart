import 'dart:io';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'file_preview_screen.dart';

class FileHistoryScreen extends StatefulWidget {
  const FileHistoryScreen({super.key});

  @override
  _FileHistoryScreenState createState() => _FileHistoryScreenState();
}

class _FileHistoryScreenState extends State<FileHistoryScreen> {
  List<String> _fileHistory = [];

  @override
  void initState() {
    super.initState();
    _loadHistory();
  }

  // Charge l'historique des fichiers partagés
  void _loadHistory() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      _fileHistory = prefs.getStringList('fileHistory') ?? [];
    });
  }

  // Supprime un fichier spécifique de l'historique
  void _deleteFile(int index) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      _fileHistory.removeAt(index);
    });
    await prefs.setStringList('fileHistory', _fileHistory);
  }

  // Supprime tout l'historique
  void _clearHistory() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      _fileHistory.clear();
    });
    await prefs.setStringList('fileHistory', _fileHistory);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Historique des fichiers partagés'),
        backgroundColor: Theme.of(context).scaffoldBackgroundColor,
        elevation: 1,
      ),
      body: Container(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            // Barre de saisie (drag handle)
            Container(
              width: 40,
              height: 5,
              margin: const EdgeInsets.symmetric(vertical: 8),
              decoration: BoxDecoration(
                color: Colors.grey[400],
                borderRadius: BorderRadius.circular(10),
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Historique des fichiers partagés',
                  style: Theme.of(context).textTheme.headlineMedium,
                ),
                Row(
                  children: [
                    if (_fileHistory.isNotEmpty)
                      TextButton(
                        onPressed: _clearHistory,
                        child: const Text(
                          'Tout supprimer',
                          style: TextStyle(color: Color(0xFFF44336)),
                        ),
                      ),
                    IconButton(
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      icon: const FaIcon(
                        FontAwesomeIcons.chevronDown,
                        color: Color(0xFF1E88E5),
                      ),
                      tooltip: 'Fermer l’historique',
                    ),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 10),
            Expanded(
              child: _fileHistory.isEmpty
                  ? Center(
                      child: Text(
                        'Aucun fichier partagé',
                        style: Theme.of(context)
                            .textTheme
                            .bodyMedium
                            ?.copyWith(color: Colors.grey),
                      ),
                    )
                  : ListView.builder(
                      itemCount: _fileHistory.length,
                      itemBuilder: (context, index) {
                        File file = File(_fileHistory[index]);
                        return Card(
                          elevation: 2,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                          margin: const EdgeInsets.symmetric(vertical: 4),
                          child: ListTile(
                            title: Text(
                              file.path.split('/').last,
                              style: Theme.of(context).textTheme.bodyMedium,
                              overflow: TextOverflow.ellipsis,
                            ),
                            trailing: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                IconButton(
                                  icon: const FaIcon(
                                    FontAwesomeIcons.eye,
                                    color: Color(0xFF1E88E5),
                                  ),
                                  onPressed: () {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                        builder: (context) =>
                                            FilePreviewScreen(file: file),
                                      ),
                                    );
                                  },
                                  tooltip: 'Prévisualiser le fichier',
                                ),
                                IconButton(
                                  icon: const FaIcon(
                                    FontAwesomeIcons.trash,
                                    color: Color(0xFFF44336),
                                  ),
                                  onPressed: () {
                                    _deleteFile(index);
                                  },
                                  tooltip: 'Supprimer le fichier',
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
