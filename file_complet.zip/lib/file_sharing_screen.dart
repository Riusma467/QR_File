import 'dart:io';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:file_picker/file_picker.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:qr_flutter/qr_flutter.dart'; // Importation pour générer le QR code
import 'file_preview_screen.dart'; // Page pour prévisualiser le fichier
import 'file_history_screen.dart'; // Page pour l'historique des fichiers

class FileSharingScreen extends StatefulWidget {
  final VoidCallback onToggleTheme;

  const FileSharingScreen({super.key, required this.onToggleTheme});

  @override
  _FileSharingScreenState createState() => _FileSharingScreenState();
}

class _FileSharingScreenState extends State<FileSharingScreen> {
  File? _selectedFile;
  bool _isLoading = false;
  List<String> _fileHistory = [];

  @override
  void initState() {
    super.initState();
    _loadHistory();
    _checkInstructions();
  }

  // Vérifie si l'utilisateur a déjà vu les instructions
  void _checkInstructions() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    bool hasSeen = prefs.getBool('seenFileSharingInstructions') ?? false;
    if (!hasSeen) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        _showInstructionsDialog();
        prefs.setBool('seenFileSharingInstructions', true);
      });
    }
  }

  // Affiche les instructions dans une boîte de dialogue
  void _showInstructionsDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Partager un fichier'),
        content: const Text(
          '1. Sélectionnez un fichier depuis votre appareil.\n'
          '2. Prévisualisez le fichier avant de partager.\n'
          '3. Appuyez sur "Partager" pour générer un QR code ou utiliser Bluetooth.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('OK', style: TextStyle(color: Color(0xFF1E88E5))),
          ),
        ],
      ),
    );
  }

  // Charge l'historique des fichiers partagés depuis SharedPreferences
  void _loadHistory() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      _fileHistory = prefs.getStringList('fileHistory') ?? [];
    });
  }

  // Sauvegarde un fichier dans l'historique
  void _saveFileToHistory(String filePath) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    _fileHistory.insert(0, filePath);
    if (_fileHistory.length > 10) _fileHistory = _fileHistory.sublist(0, 10);
    await prefs.setStringList('fileHistory', _fileHistory);
    setState(() {});
  }

  // Sélectionne un fichier depuis l'appareil
  Future<void> _pickFile() async {
    FilePickerResult? result = await FilePicker.platform.pickFiles(
      allowMultiple: false, // Un seul fichier à la fois
      type:
          FileType.any, // Permet de sélectionner n'importe quel type de fichier
    );

    if (result != null && result.files.single.path != null) {
      setState(() {
        _selectedFile = File(result.files.single.path!);
      });
    }
  }

  // Simule un upload du fichier et génère une URL (en pratique, cela nécessiterait un serveur)
  Future<String> _simulateFileUpload(File file) async {
    // Simule un délai d'upload
    await Future.delayed(const Duration(seconds: 2));

    // Génère une URL fictive pour le fichier (en pratique, cela viendrait d'un serveur)
    String fileName = file.path.split('/').last;
    return 'https://example.com/files/$fileName';
  }

  // Affiche le QR code dans une boîte de dialogue
  void _showQrCodeDialog(String url) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('QR Code pour partager le fichier'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            QrImageView(
              data: url,
              version: QrVersions.auto,
              size: 200.0,
            ),
            const SizedBox(height: 10),
            Text(
              'Scannez ce QR code pour télécharger le fichier.',
              style: Theme.of(context).textTheme.bodyMedium,
              textAlign: TextAlign.center,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Fermer',
                style: TextStyle(color: Color(0xFF1E88E5))),
          ),
        ],
      ),
    );
  }

  // Méthode pour créer une route avec un effet de fondu
  Route _createFadeRoute(Widget page) {
    return PageRouteBuilder(
      pageBuilder: (context, animation, secondaryAnimation) => page,
      transitionsBuilder: (context, animation, secondaryAnimation, child) {
        const begin = 0.0;
        const end = 1.0;
        const curve = Curves.easeInOut;

        var tween =
            Tween(begin: begin, end: end).chain(CurveTween(curve: curve));
        var opacityAnimation = animation.drive(tween);

        return FadeTransition(
          opacity: opacityAnimation,
          child: child,
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Partage de fichiers'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        backgroundColor: Theme.of(context).scaffoldBackgroundColor,
        elevation: 1,
        actions: [
          IconButton(
            icon: Icon(
              Theme.of(context).brightness == Brightness.dark
                  ? Icons.light_mode
                  : Icons.dark_mode,
            ),
            onPressed: widget.onToggleTheme,
          ),
          IconButton(
            icon: const Icon(Icons.help_outline),
            onPressed: _showInstructionsDialog,
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              'Partager un fichier',
              style: Theme.of(context).textTheme.headlineMedium,
            ),
            const SizedBox(height: 10),
            Card(
              elevation: 4,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  children: [
                    ElevatedButton.icon(
                      onPressed: _pickFile,
                      icon: const FaIcon(FontAwesomeIcons.fileUpload),
                      label: const Text('Sélectionner un fichier',
                          style: TextStyle(fontSize: 16)),
                    ),
                    const SizedBox(height: 10),
                    if (_selectedFile != null)
                      Column(
                        children: [
                          Text(
                            'Fichier sélectionné : ${_selectedFile!.path.split('/').last}',
                            style: Theme.of(context).textTheme.bodyMedium,
                            overflow: TextOverflow.ellipsis,
                          ),
                          const SizedBox(height: 10),
                          ElevatedButton.icon(
                            onPressed: () {
                              Navigator.push(
                                context,
                                _createFadeRoute(
                                    FilePreviewScreen(file: _selectedFile!)),
                              );
                            },
                            icon: const FaIcon(FontAwesomeIcons.eye),
                            label: const Text('Prévisualiser',
                                style: TextStyle(fontSize: 16)),
                          ),
                        ],
                      ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),
            _isLoading
                ? const Center(child: CircularProgressIndicator())
                : ElevatedButton.icon(
                    onPressed: _selectedFile == null
                        ? null
                        : () async {
                            if (_selectedFile != null) {
                              setState(() {
                                _isLoading = true;
                              });

                              // Simule l'upload et génère une URL
                              String fileUrl =
                                  await _simulateFileUpload(_selectedFile!);

                              setState(() {
                                _isLoading = false;
                              });

                              // Sauvegarde dans l'historique
                              _saveFileToHistory(_selectedFile!.path);

                              // Affiche le QR code
                              _showQrCodeDialog(fileUrl);

                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                  content: Text(
                                      'Fichier prêt à partager : ${_selectedFile!.path.split('/').last}'),
                                  backgroundColor: const Color(0xFF4CAF50),
                                ),
                              );

                              // Réinitialise la sélection
                              setState(() {
                                _selectedFile = null;
                              });
                            }
                          },
                    icon: const FaIcon(FontAwesomeIcons.share),
                    label:
                        const Text('Partager', style: TextStyle(fontSize: 16)),
                  ),
            const SizedBox(height: 20),
            ElevatedButton.icon(
              onPressed: () {
                Navigator.push(
                  context,
                  _createFadeRoute(FileHistoryScreen()),
                );
              },
              icon: const FaIcon(FontAwesomeIcons.history),
              label: const Text('Voir l’historique',
                  style: TextStyle(fontSize: 16)),
            ),
          ],
        ),
      ),
    );
  }
}
