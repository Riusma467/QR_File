import 'dart:io';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class FilePreviewScreen extends StatelessWidget {
  final File file;

  const FilePreviewScreen({super.key, required this.file});

  @override
  Widget build(BuildContext context) {
    // Détermine le type de fichier pour la prévisualisation
    bool isImage = file.path.endsWith('.jpg') ||
        file.path.endsWith('.jpeg') ||
        file.path.endsWith('.png') ||
        file.path.endsWith('.gif');
    bool isText = file.path.endsWith('.txt');

    return Scaffold(
      appBar: AppBar(
        title: const Text('Prévisualisation du fichier'),
        backgroundColor: Theme.of(context).scaffoldBackgroundColor,
        elevation: 1,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              'Nom du fichier : ${file.path.split('/').last}',
              style: Theme.of(context).textTheme.headlineMedium,
            ),
            const SizedBox(height: 10),
            Text(
              'Taille : ${(file.lengthSync() / 1024).toStringAsFixed(2)} KB',
              style: Theme.of(context).textTheme.bodyMedium,
            ),
            const SizedBox(height: 20),
            Expanded(
              child: isImage
                  ? Image.file(file, fit: BoxFit.contain)
                  : isText
                      ? SingleChildScrollView(
                          child: Text(
                            file.readAsStringSync(),
                            style: Theme.of(context).textTheme.bodyMedium,
                          ),
                        )
                      : Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              const FaIcon(
                                FontAwesomeIcons.file,
                                size: 50,
                                color: Color(0xFF1E88E5),
                              ),
                              const SizedBox(height: 10),
                              Text(
                                'Prévisualisation non disponible pour ce type de fichier',
                                style: Theme.of(context).textTheme.bodyMedium,
                                textAlign: TextAlign.center,
                              ),
                            ],
                          ),
                        ),
            ),
            const SizedBox(height: 20),
            ElevatedButton.icon(
              onPressed: () {
                Navigator.pop(context);
              },
              icon: const FaIcon(FontAwesomeIcons.arrowLeft),
              label: const Text('Retour', style: TextStyle(fontSize: 16)),
            ),
          ],
        ),
      ),
    );
  }
}
