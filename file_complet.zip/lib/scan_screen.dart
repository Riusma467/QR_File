import 'package:flutter/material.dart';
import 'package:qr_code_scanner/qr_code_scanner.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/services.dart' show Clipboard, ClipboardData;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class ScanScreen extends StatefulWidget {
  final VoidCallback onToggleTheme;

  const ScanScreen({super.key, required this.onToggleTheme});

  @override
  _ScanScreenState createState() => _ScanScreenState();
}

class _ScanScreenState extends State<ScanScreen> {
  final GlobalKey qrKey = GlobalKey(debugLabel: 'QR');
  Barcode? result;
  QRViewController? controller;
  bool showQrCode = false;
  String publicKey = "example-public-key-123";
  bool _hasCameraPermission = false;

  @override
  void initState() {
    super.initState();
    _checkInstructions();
    if (!kIsWeb) {
      _requestCameraPermission();
    }
  }

  // Vérifie si l'utilisateur a déjà vu les instructions
  void _checkInstructions() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    bool hasSeen = prefs.getBool('seenScanInstructions') ?? false;
    if (!hasSeen) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        _showInstructionsDialog();
        prefs.setBool('seenScanInstructions', true);
      });
    }
  }

  // Affiche les instructions dans une boîte de dialogue
  void _showInstructionsDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Scanner un QR code'),
        content: const Text(
          '1. Alignez le QR code dans le carré pour le scanner.\n'
          '2. Une fois scanné, vous pouvez ouvrir un lien, télécharger un fichier ou copier une clé publique.\n'
          '3. Appuyez sur "Afficher le code" pour générer votre propre QR code que d’autres peuvent scanner.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('OK', style: TextStyle(color: Color(0xFF1E88E5))),
          ),
        ],
      ),
    );
  }

  // Demande la permission d'accès à la caméra
  Future<void> _requestCameraPermission() async {
    if (kIsWeb) {
      setState(() {
        _hasCameraPermission = false;
      });
      return;
    }
    var status = await Permission.camera.status;
    if (status.isGranted) {
      setState(() {
        _hasCameraPermission = true;
      });
    } else {
      var result = await Permission.camera.request();
      setState(() {
        _hasCameraPermission = result.isGranted;
      });
      if (!result.isGranted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content:
                Text('L’accès à la caméra est requis pour scanner un QR code.'),
            backgroundColor: Color(0xFFF44336),
          ),
        );
      }
    }
  }

  // Simule l'envoi via Bluetooth
  Future<void> _sendViaBluetooth() async {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content:
            Text('Le Bluetooth est désactivé temporairement dans FlutLab.'),
        backgroundColor: Color(0xFFF44336),
      ),
    );
    return;
  }

  void _onQRViewCreated(QRViewController controller) {
    setState(() {
      this.controller = controller;
    });
    controller.scannedDataStream.listen((scanData) async {
      setState(() {
        result = scanData;
      });
      // Pause la caméra après avoir scanné
      controller.pauseCamera();
    });
  }

  // Ouvre une URL ou télécharge un fichier
  Future<void> _launchUrl(String url) async {
    if (await canLaunchUrl(Uri.parse(url))) {
      await launchUrl(Uri.parse(url));
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Impossible d’ouvrir le lien'),
          backgroundColor: Color(0xFFF44336),
        ),
      );
    }
  }

  // Vérifie si la chaîne scannée est une URL
  bool _isUrl(String data) {
    return data.startsWith('http://') || data.startsWith('https://');
  }

  @override
  void dispose() {
    controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Clé publique'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        backgroundColor: Theme.of(context).scaffoldBackgroundColor,
        elevation: 1,
        actions: [
          IconButton(
            icon: Icon(
              Theme.of(context).brightness == Brightness.dark
                  ? Icons.light_mode
                  : Icons.dark_mode,
            ),
            onPressed: widget.onToggleTheme,
          ),
          IconButton(
            icon: const Icon(Icons.help_outline),
            onPressed: _showInstructionsDialog,
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            if (!showQrCode) ...[
              Text(
                'Scanner une clé publique ou un lien',
                style: Theme.of(context).textTheme.headlineMedium,
              ),
              const SizedBox(height: 20),
              if (kIsWeb) ...[
                Container(
                  height: 400,
                  child: const Center(
                    child: Text(
                      'Le scan de QR code n’est pas disponible sur le web.',
                      style: TextStyle(fontSize: 18, color: Color(0xFFF44336)),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ),
              ] else if (_hasCameraPermission) ...[
                Container(
                  height: 400,
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      QRView(
                        key: qrKey,
                        onQRViewCreated: _onQRViewCreated,
                        overlay: QrScannerOverlayShape(
                          borderColor: const Color(0xFF1E88E5),
                          borderRadius: 10,
                          borderLength: 30,
                          borderWidth: 10,
                          cutOutSize: 300,
                        ),
                      ),
                      if (result != null)
                        Positioned(
                          bottom: 50,
                          child: Container(
                            padding: const EdgeInsets.all(8),
                            color: Colors.black54,
                            child: Text(
                              'Résultat : ${result!.code}',
                              style: const TextStyle(
                                  color: Colors.white, fontSize: 16),
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
                if (result != null) ...[
                  const SizedBox(height: 20),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      ElevatedButton(
                        onPressed: () async {
                          await Clipboard.setData(
                              ClipboardData(text: result!.code!));
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content:
                                  Text('Données copiées : ${result!.code}'),
                              backgroundColor: const Color(0xFF4CAF50),
                            ),
                          );
                        },
                        child: const Text('Copier'),
                      ),
                      if (_isUrl(result!.code!))
                        ElevatedButton.icon(
                          onPressed: () {
                            _launchUrl(result!.code!);
                          },
                          icon: const Icon(Icons.download),
                          label: const Text('Télécharger'),
                        )
                      else
                        ElevatedButton(
                          onPressed: () {
                            _launchUrl(result!.code!);
                          },
                          child: const Text('Ouvrir'),
                        ),
                      ElevatedButton(
                        onPressed: () {
                          setState(() {
                            result = null;
                          });
                          controller?.resumeCamera();
                        },
                        child: const Text('Scanner à nouveau'),
                      ),
                    ],
                  ),
                ],
              ] else ...[
                Container(
                  height: 400,
                  child: Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Text(
                          'Permission de caméra requise',
                          style:
                              TextStyle(fontSize: 18, color: Color(0xFFF44336)),
                        ),
                        const SizedBox(height: 10),
                        ElevatedButton(
                          onPressed: _requestCameraPermission,
                          child: const Text('Demander la permission'),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ],
            if (showQrCode) ...[
              Text(
                'Votre clé publique',
                style: Theme.of(context).textTheme.headlineMedium,
              ),
              const SizedBox(height: 20),
              Center(
                child: QrImageView(
                  data: publicKey,
                  version: QrVersions.auto,
                  size: 300.0,
                  backgroundColor: Colors.white,
                  padding: const EdgeInsets.all(10),
                  eyeStyle: const QrEyeStyle(
                    eyeShape: QrEyeShape.square,
                    color: Color(0xFF1E88E5),
                  ),
                  dataModuleStyle: const QrDataModuleStyle(
                    dataModuleShape: QrDataModuleShape.square,
                    color: Colors.black,
                  ),
                ),
              ),
              const SizedBox(height: 20),
              Text(
                'Montrez ce QR code à un autre utilisateur pour qu’il le scanne.',
                style: Theme.of(context)
                    .textTheme
                    .bodyMedium
                    ?.copyWith(color: Colors.grey),
                textAlign: TextAlign.center,
              ),
            ],
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                setState(() {
                  showQrCode = !showQrCode;
                });
                if (showQrCode) {
                  controller?.pauseCamera();
                } else {
                  controller?.resumeCamera();
                }
              },
              child: Text(
                showQrCode ? 'Revenir au scan' : 'Afficher le code',
                style: const TextStyle(fontSize: 16),
              ),
            ),
            const SizedBox(height: 10),
            if (!showQrCode)
              ElevatedButton.icon(
                onPressed: _sendViaBluetooth,
                icon: const FaIcon(FontAwesomeIcons.bluetooth),
                label: const Text('Envoyer via Bluetooth',
                    style: TextStyle(fontSize: 16)),
              ),
          ],
        ),
      ),
    );
  }
}
